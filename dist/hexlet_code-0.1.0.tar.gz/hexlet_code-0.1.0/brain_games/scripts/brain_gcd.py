from brain_games.games.game_gcd import logic_gcd


def main():
    logic_gcd()


if __name__ == '__main__':
    main()

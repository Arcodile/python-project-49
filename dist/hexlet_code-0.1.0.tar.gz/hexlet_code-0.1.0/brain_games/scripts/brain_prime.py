from brain_games.games.game_prime import logic_prime


def main():
    logic_prime()
    
    
if __name__ == '__main__':
    main()
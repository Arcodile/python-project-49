from brain_games.games.game_even import logic_even


def main():
    logic_even()
    
    
if __name__ == '__main__':
    main()
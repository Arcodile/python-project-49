from brain_games.games.game_progression import logic_progression


def main():
    logic_progression()


if __name__ == '__main__':
    main()

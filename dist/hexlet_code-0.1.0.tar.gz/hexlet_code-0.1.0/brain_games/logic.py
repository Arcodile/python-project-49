def Answer(user_answer,correct_answer,name):
    IsRight=str(user_answer)==str(correct_answer)
    Break=False
    if IsRight:
        print("Correct!")
    else:
            print("'" + str(user_answer) + "'" + " is wrong answer ;(."
                  "Correct answer was "
                  + "'" + str(correct_answer) + "'"
                  "\nLet's try again, " + name + "!")
            Break=True
    return Break
### Hexlet tests and linter status:
[![Actions Status](https://github.com/Arcodile/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Arcodile/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/a30c06db301f87cdc3df/maintainability)](https://codeclimate.com/github/Arcodile/python-project-49/maintainability)
[![asciicast](https://asciinema.org/a/3V616IZ5HZUfC9vNVMaMQITdT.svg)](https://asciinema.org/a/3V616IZ5HZUfC9vNVMaMQITdT)
from brain_games.games.game_calc import logic_calc


def main():
    logic_calc()
    
    
if __name__ == '__main__':
    main()